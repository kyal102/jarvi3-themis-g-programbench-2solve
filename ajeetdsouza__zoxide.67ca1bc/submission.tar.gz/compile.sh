#!/bin/sh
set -eu
cargo build --release --offline
cp target/release/programbench-zoxide-cleanroom executable
chmod +x executable
rm -rf target
