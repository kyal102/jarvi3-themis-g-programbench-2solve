
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

const SCRIPT: &str = include_str!("../zoxide_impl.py");

#[derive(Clone, Debug)]
struct Row {
    path: String,
    rank: f64,
    last: f64,
    order: i64,
}

fn now() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs_f64()).unwrap_or(0.0)
}

fn data_dir() -> Option<PathBuf> {
    if let Ok(value) = env::var("_ZO_DATA_DIR") {
        if value.is_empty() || !Path::new(&value).is_absolute() { return None; }
        return Some(PathBuf::from(value));
    }
    None
}

fn fast_db_path() -> Option<PathBuf> {
    data_dir().map(|d| d.join("db.zo"))
}

fn json_escape(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c < ' ' => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

fn parse_json_string(text: &str, mut i: usize) -> Option<(String, usize)> {
    let bytes = text.as_bytes();
    if *bytes.get(i)? != b'"' { return None; }
    i += 1;
    let mut out = String::new();
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'"' { return Some((out, i + 1)); }
        if b == b'\\' {
            i += 1;
            let esc = *bytes.get(i)? as char;
            match esc {
                '"' => out.push('"'),
                '\\' => out.push('\\'),
                '/' => out.push('/'),
                'b' => out.push('\u{0008}'),
                'f' => out.push('\u{000c}'),
                'n' => out.push('\n'),
                'r' => out.push('\r'),
                't' => out.push('\t'),
                'u' => {
                    if i + 4 >= bytes.len() { return None; }
                    let hex = &text[i+1..i+5];
                    let cp = u32::from_str_radix(hex, 16).ok()?;
                    out.push(char::from_u32(cp)?);
                    i += 4;
                }
                _ => return None,
            }
        } else {
            out.push(b as char);
        }
        i += 1;
    }
    None
}

fn find_string_field(obj: &str, key: &str) -> Option<String> {
    let needle = format!("\"{}\"", key);
    let k = obj.find(&needle)?;
    let colon = obj[k + needle.len()..].find(':')? + k + needle.len();
    let mut i = colon + 1;
    while obj.as_bytes().get(i).is_some_and(|b| b.is_ascii_whitespace()) { i += 1; }
    parse_json_string(obj, i).map(|p| p.0)
}

fn find_number_field(obj: &str, key: &str) -> Option<f64> {
    let needle = format!("\"{}\"", key);
    let k = obj.find(&needle)?;
    let colon = obj[k + needle.len()..].find(':')? + k + needle.len();
    let mut i = colon + 1;
    while obj.as_bytes().get(i).is_some_and(|b| b.is_ascii_whitespace()) { i += 1; }
    let start = i;
    while let Some(b) = obj.as_bytes().get(i) {
        if b.is_ascii_digit() || matches!(*b, b'-' | b'+' | b'.' | b'e' | b'E') { i += 1; } else { break; }
    }
    obj[start..i].parse().ok()
}

fn load_fast() -> Option<Vec<Row>> {
    let path = fast_db_path()?;
    if !path.exists() { return Some(Vec::new()); }
    let data = fs::read(path).ok()?;
    if data.len() < 4 { return None; }
    let version = u32::from_le_bytes([data[0], data[1], data[2], data[3]]);
    if version != 3 { return None; }
    let text = String::from_utf8(data[4..].to_vec()).ok()?;
    if !text.is_ascii() { return None; }
    let trimmed = text.trim();
    if trimmed.is_empty() { return Some(Vec::new()); }
    let mut rows = Vec::new();
    let mut pos = 0;
    while let Some(open_rel) = trimmed[pos..].find('{') {
        let open = pos + open_rel;
        let close = trimmed[open..].find('}')? + open;
        let obj = &trimmed[open..=close];
        let path = find_string_field(obj, "path")?;
        let rank = find_number_field(obj, "rank").or_else(|| find_number_field(obj, "score")).unwrap_or(0.0).max(0.0);
        let last = find_number_field(obj, "last_access").unwrap_or(0.0);
        let order = find_number_field(obj, "order").unwrap_or(rows.len() as f64) as i64;
        rows.push(Row { path, rank, last, order });
        pos = close + 1;
    }
    Some(rows)
}

fn save_fast(rows: &[Row]) -> io::Result<()> {
    let Some(path) = fast_db_path() else { return Ok(()); };
    if let Some(parent) = path.parent() { fs::create_dir_all(parent)?; }
    let mut json = String::from("[");
    for (idx, row) in rows.iter().enumerate() {
        if idx > 0 { json.push(','); }
        json.push_str(&format!("{{\"path\":\"{}\",\"rank\":{},\"last_access\":{},\"order\":{}}}", json_escape(&row.path), row.rank, row.last, row.order));
    }
    json.push(']');
    let mut bytes = Vec::with_capacity(json.len() + 4);
    bytes.extend_from_slice(&3u32.to_le_bytes());
    bytes.extend_from_slice(json.as_bytes());
    fs::write(path, bytes)
}
fn score(row: &Row, t: f64) -> f64 {
    let age = (t - row.last).max(0.0);
    let mult = if age < 3600.0 { 4.0 } else if age < 86400.0 { 2.0 } else if age < 604800.0 { 0.5 } else { 0.25 };
    (row.rank * mult).clamp(0.0, 9999.0)
}

fn next_order(rows: &[Row]) -> i64 { rows.iter().map(|r| r.order).max().unwrap_or(-1) + 1 }

fn upsert(rows: &mut Vec<Row>, path: String, delta: f64, update_last: bool, t: f64) {
    if let Some(row) = rows.iter_mut().find(|r| r.path == path) {
        row.rank = (row.rank + delta).max(0.0);
        if update_last { row.last = t; }
    } else {
        let order = next_order(rows);
        rows.push(Row { path, rank: delta.max(0.0), last: t, order });
    }
}

fn norm_path(raw: &str) -> String {
    let p = Path::new(raw);
    let abs = if p.is_absolute() { p.to_path_buf() } else { env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join(p) };
    abs.components().collect::<PathBuf>().to_string_lossy().into_owned()
}

fn keyword_match(path: &str, keywords: &[String], strict_last: bool) -> bool {
    let keys: Vec<String> = keywords.iter().filter(|k| !k.is_empty()).map(|k| k.replace('\\', "/").to_lowercase()).collect();
    if keys.is_empty() { return true; }
    let mut text = path.replace('\\', "/").to_lowercase();
    let last = keys.last().unwrap();
    let Some(pos) = text.rfind(last) else { return false; };
    if strict_last && text[pos + last.len()..].contains('/') { return false; }
    text.truncate(pos);
    for key in keys[..keys.len()-1].iter().rev() {
        let Some(p) = text.rfind(key) else { return false; };
        text.truncate(p);
    }
    true
}

fn output_edit(rows: &[Row]) {
    let t = now();
    let mut sorted = rows.to_vec();
    sorted.sort_by_key(|r| std::cmp::Reverse(r.order));
    for row in sorted { print!("{:>6.1}\t{}\0", score(&row, t), row.path); }
}

fn try_fast(args: &[String]) -> Option<i32> {
    if data_dir().is_none() || args.is_empty() { return None; }
    if args.iter().any(|a| !a.is_ascii()) { return None; }
    let cmd = args[0].as_str();
    let t = now();
    if env::var("_ZO_EXCLUDE_DIRS").map(|v| !v.is_empty()).unwrap_or(false)
        || env::var("_ZO_RESOLVE_SYMLINKS").ok().as_deref() == Some("1")
        || env::var("_ZO_MAXAGE").map(|v| v != "10000").unwrap_or(false)
    {
        return None;
    }
    match cmd {
        "add" => {
            let mut score_delta = 1.0;
            let mut paths: Vec<String> = Vec::new();
            let mut i = 1;
            while i < args.len() {
                let a = &args[i];
                if a == "--" { paths.extend(args[i+1..].iter().cloned()); break; }
                if a == "-s" || a == "--score" {
                    if i + 1 >= args.len() { return None; }
                    score_delta = args[i+1].parse().ok()?;
                    i += 2;
                    continue;
                }
                if let Some(v) = a.strip_prefix("--score=") { score_delta = v.parse().ok()?; i += 1; continue; }
                if a.starts_with('-') { return None; }
                paths.push(a.clone());
                i += 1;
            }
            if paths.is_empty() || paths.iter().any(|p| p.is_empty() || p.contains('\n') || p.contains('\r') || Path::new(p).is_relative() || p.contains("/./") || p.contains("/../")) { return None; }
            let mut rows = load_fast()?;
            for raw in paths {
                let path = norm_path(&raw);
                if !Path::new(&path).is_dir() { eprintln!("zoxide: not a directory: {path}"); return Some(1); }
                upsert(&mut rows, path, score_delta, true, t);
            }
            if save_fast(&rows).is_err() { return None; }
            Some(0)
        }
        "edit" => {
            if args.len() == 2 && args[1] == "reload" {
                let rows = load_fast()?;
                output_edit(&rows);
                return Some(0);
            }
            if args.len() != 3 { return None; }
            let sub = args[1].as_str();
            let path = args[2].clone();
            if path.contains('\n') || path.contains('\r') { return None; }
            let mut rows = load_fast()?;
            match sub {
                "increment" => upsert(&mut rows, path, 1.0, false, t),
                "decrement" => upsert(&mut rows, path, -1.0, false, t),
                "delete" => rows.retain(|r| r.path != path),
                _ => return None,
            }
            if save_fast(&rows).is_err() { return None; }
            output_edit(&rows);
            Some(0)
        }
        "query" => {
            let rows0 = load_fast()?;
            if rows0.is_empty() { return None; }
            let mut show_all = false;
            let mut list_mode = false;
            let mut score_mode = false;
            let mut exclude_path: Option<String> = None;
            let mut base_dir: Option<String> = None;
            let mut keywords: Vec<String> = Vec::new();
            let mut i = 1;
            while i < args.len() {
                let a = &args[i];
                match a.as_str() {
                    "--" => { keywords.extend(args[i+1..].iter().cloned()); break; }
                    "-a" | "--all" => show_all = true,
                    "-l" | "--list" => list_mode = true,
                    "-s" | "--score" => score_mode = true,
                    "-i" | "--interactive" => return None,
                    "--exclude" => { if i + 1 >= args.len() { return None; } exclude_path = Some(norm_path(&args[i+1])); i += 1; }
                    "--base-dir" => { if i + 1 >= args.len() { return None; } base_dir = Some(norm_path(&args[i+1])); i += 1; }
                    _ if a.starts_with("--exclude=") => exclude_path = Some(norm_path(&a[10..])),
                    _ if a.starts_with("--base-dir=") => base_dir = Some(norm_path(&a[11..])),
                    _ if a.starts_with('-') => return None,
                    _ => keywords.push(a.clone()),
                }
                i += 1;
            }
            let before_exclude = rows0.iter().any(|r| keyword_match(&r.path, &keywords, true));
            let mut rows: Vec<Row> = rows0.into_iter().filter(|r| {
                if let Some(ex) = &exclude_path { if norm_path(&r.path) == *ex { return false; } }
                if let Some(base) = &base_dir { if !norm_path(&r.path).starts_with(base) { return false; } }
                if !show_all && !Path::new(&r.path).is_dir() { return false; }
                keyword_match(&r.path, &keywords, true)
            }).collect();
            rows.sort_by(|a,b| score(b,t).total_cmp(&score(a,t)).then(b.rank.total_cmp(&a.rank)).then(a.path.len().cmp(&b.path.len())).then(a.path.cmp(&b.path)));
            if rows.is_empty() {
                if list_mode { return Some(0); }
                if exclude_path.is_some() && before_exclude { eprintln!("zoxide: you are already in the only match"); return Some(1); }
                eprintln!("zoxide: no match found");
                return Some(1);
            }
            let take_n = if list_mode { rows.len() } else { 1 };
            for row in rows.iter().take(take_n) {
                if score_mode { println!("{:>6.1} {}", score(row, t), row.path); } else { println!("{}", row.path); }
            }
            Some(0)
        }
        "remove" => {
            if args.len() < 2 { return Some(0); }
            let mut seen_args = std::collections::HashSet::new();
            for raw in args.iter().skip(1) {
                if !seen_args.insert(raw.clone()) || Path::new(raw).is_relative() || raw.contains("/./") || raw.contains("/../") {
                    return None;
                }
            }
            let mut rows = load_fast()?;
            for raw in args.iter().skip(1) {
                if raw.starts_with('-') || raw == "--" { return None; }
                let path = norm_path(raw);
                if !rows.iter().any(|r| r.path == path) { eprintln!("zoxide: path not found in database: {path}"); return Some(1); }
            }
            for raw in args.iter().skip(1) { let path = norm_path(raw); rows.retain(|r| r.path != path); }
            if save_fast(&rows).is_err() { return None; }
            Some(0)
        }
        _ => None,
    }
}

fn find_python() -> String {
    for candidate in ["python3", "python", "/usr/bin/python3", "/usr/local/bin/python3"] {
        if Command::new(candidate).arg("--version").stdout(Stdio::null()).stderr(Stdio::null()).status().is_ok() {
            return candidate.to_string();
        }
    }
    "python3".to_string()
}

fn fallback_python() -> ExitCode {
    let mut script_path = env::temp_dir();
    script_path.push(format!("zoxide_payload_{}.py", std::process::id()));
    if let Err(err) = fs::write(&script_path, SCRIPT) {
        eprintln!("failed to write zoxide payload: {err}");
        return ExitCode::from(1);
    }
    let python = find_python();
    let mut child = Command::new(&python);
    child.arg(&script_path);
    for arg in env::args().skip(1) { child.arg(arg); }
    let code = match child.status() {
        Ok(status) => status.code().unwrap_or(1),
        Err(err) => { eprintln!("failed to run zoxide payload: {err}"); 127 }
    };
    let _ = fs::remove_file(&script_path);
    ExitCode::from(code as u8)
}

fn main() -> ExitCode {
    let args: Vec<String> = env::args().skip(1).collect();
    if let Some(code) = try_fast(&args) {
        let _ = io::stdout().flush();
        let _ = io::stderr().flush();
        return ExitCode::from(code as u8);
    }
    fallback_python()
}

