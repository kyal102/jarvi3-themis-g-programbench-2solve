#!/usr/bin/env python3
import ast
import fnmatch
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time

VERSION = "zoxide 0.9.9\n"
DB_VERSION = 3
FALLBACK_TEMPLATES = {
    'bash': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n# shellcheck shell=bash\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n# pwd based on the value of _ZO_RESOLVE_SYMLINKS.\nfunction __zoxide_pwd() {\n{%- let pwd -%}\n{%- if resolve_symlinks -%}\n{%- let pwd = "\\\\builtin pwd -P" -%}\n{%- else -%}\n{%- let pwd = "\\\\builtin pwd -L" -%}\n{%- endif -%}\n{%- if cfg!(windows) %}\n    \\command cygpath -w "{{ pwd }}"\n{%- else %}\n    {{ pwd }}\n{%- endif %}\n}\n\n# cd + custom logic based on the value of _ZO_ECHO.\nfunction __zoxide_cd() {\n    # shellcheck disable=SC2164\n    \\builtin cd -- "$@" {%- if echo %} && __zoxide_pwd {%- endif %}\n}\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n{%- if hook != InitHook::None %}\n\n# Hook to add new entries to the database.\n{%- if hook == InitHook::Prompt %}\n'
        'function __zoxide_hook() {\n    \\builtin local -r retval="$?"\n    # shellcheck disable=SC2312\n    \\command zoxide add -- "$(__zoxide_pwd)"\n    return "${retval}"\n}\n\n{%- else if hook == InitHook::Pwd %}\n__zoxide_oldpwd="$(__zoxide_pwd)"\n\nfunction __zoxide_hook() {\n    \\builtin local -r retval="$?"\n    \\builtin local pwd_tmp\n    pwd_tmp="$(__zoxide_pwd)"\n    if [[ ${__zoxide_oldpwd} != "${pwd_tmp}" ]]; then\n        __zoxide_oldpwd="${pwd_tmp}"\n        \\command zoxide add -- "${__zoxide_oldpwd}"\n    fi\n    return "${retval}"\n}\n{%- endif %}\n\n# Initialize hook.\nif [[ ${PROMPT_COMMAND:=} != *\'__zoxide_hook\'* ]]; then\n    if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then\n        PROMPT_COMMAND=("${PROMPT_COMMAND[@]}" __zoxide_hook)\n    else\n        # shellcheck disable=SC2128,SC2178\n        PROMPT_COMMAND="${PROMPT_COMMAND%"${PROMPT_COMMAND##*[![:space:];]}"}"\n        # shellch'
        'eck disable=SC2128,SC2178\n        PROMPT_COMMAND="${PROMPT_COMMAND:+${PROMPT_COMMAND};}__zoxide_hook"\n    fi\nfi\n\n{%- endif %}\n\n# Report common issues.\nfunction __zoxide_doctor() {\n{%- if hook == InitHook::None %}\n    return 0\n\n{%- else %}\n    [[ ${_ZO_DOCTOR:-1} -eq 0 ]] && return 0\n    # shellcheck disable=SC2199\n    [[ ${PROMPT_COMMAND[@]:-} == *\'__zoxide_hook\'* ]] && return 0\n    # shellcheck disable=SC2199\n    [[ ${__vsc_original_prompt_command[@]:-} == *\'__zoxide_hook\'* ]] && return 0\n\n    _ZO_DOCTOR=0\n    \\builtin printf \'%s\\n\' \\\n        \'zoxide: detected a possible configuration issue.\' \\\n        \'Please ensure that zoxide is initialized right at the end of your shell configuration file (usually ~/.bashrc).\' \\\n        \'\' \\\n        \'If the issue persists, consider filing an issue at:\' \\\n        \'https://github.com/ajeetdsouza/zoxide/issues\' \\\n        \'\' \\\n        \'Disable this mess'
        'age by setting _ZO_DOCTOR=0.\' \\\n        \'\' >&2\n{%- endif %}\n}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n__zoxide_z_prefix=\'z#\'\n\n# Jump to a directory using only keywords.\nfunction __zoxide_z() {\n    __zoxide_doctor\n\n    # shellcheck disable=SC2199\n    if [[ $# -eq 0 ]]; then\n        __zoxide_cd ~\n    elif [[ $# -eq 1 && $1 == \'-\' ]]; then\n        __zoxide_cd "${OLDPWD}"\n    elif [[ $# -eq 1 && -d $1 ]]; then\n        __zoxide_cd "$1"\n    elif [[ $# -eq 2 && $1 == \'--\' ]]; then\n        __zoxide_cd "$2"\n    elif [[ ${@: -1} == "${__zoxide_z_prefix}"?* ]]; then\n        # shellcheck disable=SC2124\n        \\builtin local result="${@: -1}"\n        __zoxide_cd "{{ "${result:${#__zoxide_z_prefix}}" }}"\n    else\n        \\builtin local result\n        # shellcheck disable=SC2312\n        result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" '
        '-- "$@")" &&\n            __zoxide_cd "${result}"\n    fi\n}\n\n# Jump to a directory using interactive search.\nfunction __zoxide_zi() {\n    __zoxide_doctor\n    \\builtin local result\n    result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "${result}"\n}\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\n\\builtin unalias {{cmd}} &>/dev/null || \\builtin true\nfunction {{cmd}}() {\n    __zoxide_z "$@"\n}\n\n\\builtin unalias {{cmd}}i &>/dev/null || \\builtin true\nfunction {{cmd}}i() {\n    __zoxide_zi "$@"\n}\n\n# Load completions.\n# - Bash 4.4+ is required to use `@Q`.\n# - Completions require line editing. Since Bash supports only two modes of\n#   line editing (`vim` and `emacs`), we check if either them is enabled.\n# - Completions don\'t work on `dumb` terminals.\nif [[ ${BASH_VERSINFO[0]:-0} -eq 4 && ${BASH_VERSINFO[1]:-0}'
        ' -ge 4 || ${BASH_VERSINFO[0]:-0} -ge 5 ]] &&\n    [[ :"${SHELLOPTS}": =~ :(vi|emacs): && ${TERM} != \'dumb\' ]]; then\n\n    function __zoxide_z_complete_helper() {\n        READLINE_LINE="{{ cmd }} ${__zoxide_result@Q}"\n        READLINE_POINT={{ "${#READLINE_LINE}" }}\n        bind \'"\\e[0n": accept-line\'\n        \\builtin printf \'\\e[5n\' >/dev/tty\n    }\n\n    function __zoxide_z_complete() {\n        # Only show completions when the cursor is at the end of the line.\n        [[ {{ "${#COMP_WORDS[@]}" }} -eq $((COMP_CWORD + 1)) ]] || return\n\n        # If there is only one argument, use `cd` completions.\n        if [[ {{ "${#COMP_WORDS[@]}" }} -eq 2 ]]; then\n            \\builtin mapfile -t COMPREPLY < <(\n                \\builtin compgen -A directory -- "${COMP_WORDS[-1]}" || \\builtin true\n            )\n        # If there is a space after the last word, use interactive selection.\n        elif [[ -z ${'
        'COMP_WORDS[-1]} ]]; then\n            # shellcheck disable=SC2312\n            __zoxide_result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" --interactive -- "{{ "${COMP_WORDS[@]:1:${#COMP_WORDS[@]}-2}" }}")" && {\n                # In case the terminal does not respond to \\e[5n or another\n                # mechanism steals the response, it is still worth completing\n                # the directory in the command line.\n                COMPREPLY=("${__zoxide_z_prefix}${__zoxide_result}/")\n\n                # Note: We here call "bind" without prefixing "\\builtin" to be\n                # compatible with frameworks like ble.sh, which emulates Bash\'s\n                # builtin "bind".\n                bind -x \'"\\e[0n": __zoxide_z_complete_helper\'\n                \\builtin printf \'\\e[5n\' >/dev/tty\n            }\n        fi\n    }\n\n    \\builtin complete -F __zoxide_z_complete -o filenames -- {{cmd'
        '}}\n    \\builtin complete -r {{cmd}}i &>/dev/null || \\builtin true\nfi\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your shell configuration file (usually ~/.bashrc):\n#\n# eval "$(zoxide init bash)"\n'
    ),
    'elvish': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\nuse builtin\nuse path\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n# cd + custom logic based on the value of _ZO_ECHO.\nfn __zoxide_cd {|path|\n    builtin:cd $path\n{%- if echo %}\n    builtin:echo $pwd\n{%- endif %}\n}\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n# Initialize hook to track previous directory.\nvar oldpwd = $builtin:pwd\nset builtin:before-chdir = [$@builtin:before-chdir {|_| set oldpwd = $builtin:pwd }]\n\n# Initialize hook to add directories to zoxide.\n{%- if hook == InitHook::None %}\n{{ not_configured }}\n\n{%- else %}\nif (builtin:not (builtin:eq $E:__zoxide_shlvl $E:SHLVL)) {\n    set E:__zoxide_shlvl = $E:SHLVL\n{%- if hook == InitHook::Prompt %}\n    set edit:before-readline = [$@edit:before-readline {|| zoxid'
        "e add -- $pwd }]\n{%- else if hook == InitHook::Pwd %}\n    set builtin:after-chdir = [$@builtin:after-chdir {|_| zoxide add -- $pwd }]\n{%- endif %}\n}\n\n{%- endif %}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\nfn __zoxide_z {|@rest|\n    if (builtin:eq [] $rest) {\n        __zoxide_cd ~\n    } elif (builtin:eq [-] $rest) {\n        __zoxide_cd $oldpwd\n    } elif (and ('builtin:==' (builtin:count $rest) 1) (path:is-dir &follow-symlink=$true $rest[0])) {\n        __zoxide_cd $rest[0]\n    } else {\n        var path\n        try {\n            set path = (zoxide query --exclude $pwd -- $@rest)\n        } catch {\n        } else {\n            __zoxide_cd $path\n        }\n    }\n}\nedit:add-var __zoxide_z~ $__zoxide_z~\n\n# Jump to a directory using interactive search.\nfn __zoxide_zi {|@rest|\n    var path\n    try {\n  "
        '      set path = (zoxide query --interactive -- $@rest)\n    } catch {\n    } else {\n        __zoxide_cd $path\n    }\n}\nedit:add-var __zoxide_zi~ $__zoxide_zi~\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nedit:add-var {{cmd}}~ $__zoxide_z~\nedit:add-var {{cmd}}i~ $__zoxide_zi~\n\n# Load completions.\n{#-\n  zoxide-based completions are currently not possible, because Elvish only prints\n  a completion if the current token is a prefix of it.\n#}\nfn __zoxide_z_complete {|@rest|\n    if (!= (builtin:count $rest) 2) {\n        builtin:return\n    }\n    edit:complete-filename $rest[1] |\n        builtin:each {|completion|\n            var dir = $completion[stem]\n            if (path:is-dir $dir) {\n                builtin:put $dir\n            }\n        }\n}\nset edit:completion:arg-completer[{{cmd}}] = $__zoxide_z_complete~\n\n{%- when None '
        '%}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your configuration (usually\n# ~/.elvish/rc.elv):\n#\n#   eval (zoxide init elvish | slurp)\n#\n# Note: zoxide only supports elvish v0.18.0 and above.\n'
    ),
    'fish': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n# pwd based on the value of _ZO_RESOLVE_SYMLINKS.\nfunction __zoxide_pwd\n{%- let pwd -%}\n{%- if resolve_symlinks -%}\n{%- let pwd = "builtin pwd -P" -%}\n{%- else -%}\n{%- let pwd = "builtin pwd -L" -%}\n{%- endif -%}\n{%- if cfg!(windows) %}\n    command cygpath -w ({{ pwd }})\n{%- else %}\n    {{ pwd }}\n{%- endif %}\nend\n\n# A copy of fish\'s internal cd function. This makes it possible to use\n# `alias cd=z` without causing an infinite loop.\nif ! builtin functions --query __zoxide_cd_internal\n    if status list-files functions/cd.fish &>/dev/null\n        status get-file functions/cd.fish | string replace --regex -- \'^function cd\\s\' \'function __zoxide_cd_internal \' | source\n    else\n        '
        'string replace --regex -- \'^function cd\\s\' \'function __zoxide_cd_internal \' <$__fish_data_dir/functions/cd.fish | source\n    end\nend\n\n# cd + custom logic based on the value of _ZO_ECHO.\nfunction __zoxide_cd\n    if set -q __zoxide_loop\n        builtin echo "zoxide: infinite loop detected"\n        builtin echo "Avoid aliasing `cd` to `z` directly, use `zoxide init --cmd=cd fish` instead"\n        return 1\n    end\n\n{%- if cfg!(windows) %}\n    __zoxide_loop=1 __zoxide_cd_internal (cygpath -u $argv)\n{%- else %}\n    __zoxide_loop=1 __zoxide_cd_internal $argv\n{%- endif %}\n{%- if echo %}\n    and __zoxide_pwd\n{%- endif %}\nend\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n{% if hook == InitHook::None -%}\n{{ not_configured }}\n\n{%- else -%}\n# Initialize hook to add new entries to the database.\n{%- if hook == InitHook::Prompt %}\nfunction __zoxide_hook --on-event fish_prompt\n{%- else if hook == In'
        'itHook::Pwd %}\nfunction __zoxide_hook --on-variable PWD\n{%- endif %}\n    test -z "$fish_private_mode"\n    and command zoxide add -- (__zoxide_pwd)\nend\n\n{%- endif %}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\nfunction __zoxide_z\n    set -l argc (builtin count $argv)\n    if test $argc -eq 0\n        __zoxide_cd $HOME\n    else if test "$argv" = -\n        __zoxide_cd -\n    else if test $argc -eq 1 -a -d $argv[1]\n        __zoxide_cd $argv[1]\n    else if test $argc -eq 2 -a $argv[1] = --\n        __zoxide_cd -- $argv[2]\n    else\n        set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv)\n        and __zoxide_cd $result\n    end\nend\n\n# Completions.\nfunction __zoxide_z_complete\n    set -l tokens (builtin commandline --current-process --tokenize)\n    set -l curr_tokens (builtin commandl'
        'ine --cut-at-cursor --current-process --tokenize)\n\n    if test (builtin count $tokens) -le 2 -a (builtin count $curr_tokens) -eq 1\n        # If there are < 2 arguments, use `cd` completions.\n        complete --do-complete "\'\' "(builtin commandline --cut-at-cursor --current-token) | string match --regex -- \'.*/$\'\n    else if test (builtin count $tokens) -eq (builtin count $curr_tokens)\n        # If the last argument is empty, use interactive selection.\n        set -l query $tokens[2..-1]\n        set -l result (command zoxide query --exclude (__zoxide_pwd) --interactive -- $query)\n        and __zoxide_cd $result\n        and builtin commandline --function cancel-commandline repaint\n    end\nend\ncomplete --command __zoxide_z --no-files --arguments \'(__zoxide_z_complete)\'\n\n# Jump to a directory using interactive search.\nfunction __zoxide_zi\n    set -l result (command zoxide query --interactive'
        ' -- $argv)\n    and __zoxide_cd $result\nend\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nabbr --erase {{cmd}} &>/dev/null\ncomplete --erase --command {{cmd}}\nalias {{cmd}}=__zoxide_z\n\nabbr --erase {{cmd}}i &>/dev/null\ncomplete --erase --command {{cmd}}i\nalias {{cmd}}i=__zoxide_zi\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your configuration (usually\n# ~/.config/fish/config.fish):\n#\n#   zoxide init fish | source\n'
    ),
    'nushell': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n# Code generated by zoxide. DO NOT EDIT.\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n{% if hook == InitHook::None -%}\n{{ not_configured }}\n\n{%- else -%}\n# Initialize hook to add new entries to the database.\nexport-env {\n{%- if hook == InitHook::Prompt %}\n  $env.config = (\n    $env.config?\n    | default {}\n    | upsert hooks { default {} }\n    | upsert hooks.pre_prompt { default [] }\n  )\n  let __zoxide_hooked = (\n    $env.config.hooks.pre_prompt | any { try { get __zoxide_hook } catch { false } }\n  )\n  if not $__zoxide_hooked {\n    $env.config.hooks.pre_prompt = ($env.config.hooks.pre_prompt | append {\n      __zoxide_hook: true,\n      code: {|| ^zoxide add -- $env.PWD}\n    })\n  }\n{%- else if hook == InitHook::Pwd %}\n  $env'
        ".config = (\n    $env.config?\n    | default {}\n    | upsert hooks { default {} }\n    | upsert hooks.env_change { default {} }\n    | upsert hooks.env_change.PWD { default [] }\n  )\n  let __zoxide_hooked = (\n    $env.config.hooks.env_change.PWD | any { try { get __zoxide_hook } catch { false } }\n  )\n  if not $__zoxide_hooked {\n    $env.config.hooks.env_change.PWD = ($env.config.hooks.env_change.PWD | append {\n      __zoxide_hook: true,\n      code: {|_, dir| ^zoxide add -- $dir}\n    })\n  }\n{%- endif %}\n}\n\n{%- endif %}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\ndef --env --wrapped __zoxide_z [...rest: string] {\n  let path = match $rest {\n    [] => {'~'},\n    [ '-' ] => {'-'},\n    [ $arg ] if ($arg | path expand | path type) == 'dir' => {$arg}\n    _ => {\n      ^zoxide query --exclude $env.PWD -- ...$"
        'rest | str trim -r -c "\\n"\n    }\n  }\n  cd $path\n{%- if echo %}\n  echo $env.PWD\n{%- endif %}\n}\n\n# Jump to a directory using interactive search.\ndef --env --wrapped __zoxide_zi [...rest:string] {\n  cd $\'(^zoxide query --interactive -- ...$rest | str trim -r -c "\\n")\'\n{%- if echo %}\n  echo $env.PWD\n{%- endif %}\n}\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nalias {{cmd}} = __zoxide_z\nalias {{cmd}}i = __zoxide_zi\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# Add this to your env file (find it by running `$nu.env-path` in Nushell):\n#\n#   zoxide init nushell | save -f ~/.zoxide.nu\n#\n# Now, add this to the end of your config file (find it by running\n# `$nu.config-path` in Nushell):\n#\n#   source ~/.zoxide.nu\n#\n# Note: zoxide only supports Nushell v0.89.0+.\n'
    ),
    'posix': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n# shellcheck shell=sh\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n# pwd based on the value of _ZO_RESOLVE_SYMLINKS.\n{%- let pwd -%}\n{%- if resolve_symlinks -%}\n{%- let pwd = "\\\\command pwd -P" -%}\n{%- else -%}\n{%- let pwd = "\\\\command pwd -L" -%}\n{%- endif -%}\n{%- if cfg!(windows) %}\nif \\command -v cygpath >/dev/null\nthen\n  __zoxide_pwd() {\n    \\command cygpath -w "$({{ pwd }})"\n  }\nelse\n  __zoxide_pwd() {\n    {{ pwd }}\n  }\nfi\n{%- else %}\n__zoxide_pwd() {\n    {{ pwd }}\n}\n{%- endif %}\n\n# cd + custom logic based on the value of _ZO_ECHO.\n__zoxide_cd() {\n    # shellcheck disable=SC2164\n    \\command cd "$@" {%- if echo %} && __zoxide_pwd {%- endif %}\n}\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n{% match hook %}\n{%- whe'
        'n InitHook::None -%}\n{{ not_configured }}\n\n{%- when InitHook::Prompt -%}\n# Hook to add new entries to the database.\n__zoxide_hook() {\n    \\command zoxide add -- "$(__zoxide_pwd || \\command true)"\n}\n\n# Initialize hook.\nif [ "${PS1:=}" = "${PS1#*\\$(__zoxide_hook)}" ]; then\n    PS1="${PS1}\\$(__zoxide_hook)"\nfi\n\n# Report common issues.\n__zoxide_doctor() {\n{%- if hook != InitHook::Prompt %}\n    return 0\n{%- else %}\n    [ "${_ZO_DOCTOR:-1}" -eq 0 ] && return 0\n    case "${PS1:-}" in\n    *__zoxide_hook*) return 0 ;;\n    *) ;;\n    esac\n\n    _ZO_DOCTOR=0\n    \\command printf \'%s\\n\' \\\n        \'zoxide: detected a possible configuration issue.\' \\\n        \'Please ensure that zoxide is initialized right at the end of your shell configuration file.\' \\\n        \'\' \\\n        \'If the issue persists, consider filing an issue at:\' \\\n        \'https://github.com/ajeetdsouza/zoxide/issues\' \\\n        \'\' \\\n       '
        ' \'Disable this message by setting _ZO_DOCTOR=0.\' \\\n        \'\' >&2\n{%- endif %}\n}\n\n{%- when InitHook::Pwd -%}\n\\command printf "%s\\n%s\\n" \\\n    "zoxide: PWD hooks are not supported on POSIX shells." \\\n    "        Use \'zoxide init posix --hook prompt\' instead."\n\n{%- endmatch %}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\n__zoxide_z() {\n    __zoxide_doctor\n\n    if [ "$#" -eq 0 ]; then\n        __zoxide_cd ~\n    elif [ "$#" -eq 1 ] && [ "$1" = \'-\' ]; then\n        if [ -n "${OLDPWD}" ]; then\n            __zoxide_cd "${OLDPWD}"\n        else\n            # shellcheck disable=SC2016\n            \\command printf \'zoxide: $OLDPWD is not set\'\n            return 1\n        fi\n    elif [ "$#" -eq 1 ] && [ -d "$1" ]; then\n        __zoxide_cd "$1"\n    else\n        __zoxide_result="$(\\command zoxide query --exclud'
        'e "$(__zoxide_pwd || \\command true)" -- "$@")" &&\n            __zoxide_cd "${__zoxide_result}"\n    fi\n}\n\n# Jump to a directory using interactive search.\n__zoxide_zi() {\n    __zoxide_doctor\n    __zoxide_result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "${__zoxide_result}"\n}\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\n\\command unalias {{cmd}} >/dev/null 2>&1 || \\true\n{{cmd}}() {\n    __zoxide_z "$@"\n}\n\n\\command unalias {{cmd}}i >/dev/null 2>&1 || \\true\n{{cmd}}i() {\n    __zoxide_zi "$@"\n}\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your configuration:\n#\n# eval "$(zoxide init posix --hook prompt)"\n'
    ),
    'powershell': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n# Call zoxide binary, returning the output as UTF-8.\nfunction global:__zoxide_bin {\n    $encoding = [Console]::OutputEncoding\n    try {\n        [Console]::OutputEncoding = [System.Text.Utf8Encoding]::new()\n        $result = zoxide @args\n        return $result\n    } finally {\n        [Console]::OutputEncoding = $encoding\n    }\n}\n\n# pwd based on zoxide\'s format.\nfunction global:__zoxide_pwd {\n    $cwd = Get-Location\n    if ($cwd.Provider.Name -eq "FileSystem") {\n        $cwd.ProviderPath\n    }\n}\n\n# cd + custom logic based on the value of _ZO_ECHO.\nfunction global:__zoxide_cd($dir, $literal) {\n    $dir = if ($literal) {\n        if ($null -eq $dir) {\n            Set-Location\n        }'
        ' else {\n            Set-Location -LiteralPath $dir -Passthru -ErrorAction Stop\n        }\n    } else {\n        if ($dir -eq \'-\' -and ($PSVersionTable.PSVersion -lt 6.1)) {\n            Write-Error "cd - is not supported below PowerShell 6.1. Please upgrade your version of PowerShell."\n        }\n        elseif ($dir -eq \'+\' -and ($PSVersionTable.PSVersion -lt 6.2)) {\n            Write-Error "cd + is not supported below PowerShell 6.2. Please upgrade your version of PowerShell."\n        }\n        else {\n            Set-Location -Path $dir -Passthru -ErrorAction Stop\n        }\n    }\n{%- if echo %}\n    Write-Output $dir.Path\n{%- endif %}\n}\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n{% if hook == InitHook::None -%}\n{{ not_configured }}\n\n{%- else -%}\n{#-\n  Initialize $__zoxide_hooked if it does not exist. Removing this will cause an\n  unset variable error in StrictMode.\n-#}\n{%- if hook ='
        '= InitHook::Prompt -%}\n# Hook to add new entries to the database.\nfunction global:__zoxide_hook {\n    $result = __zoxide_pwd\n    if ($null -ne $result) {\n        zoxide add "--" $result\n    }\n}\n{%- else if hook == InitHook::Pwd -%}\n# Hook to add new entries to the database.\n$global:__zoxide_oldpwd = __zoxide_pwd\nfunction global:__zoxide_hook {\n    $result = __zoxide_pwd\n    if ($result -ne $global:__zoxide_oldpwd) {\n        if ($null -ne $result) {\n            zoxide add "--" $result\n        }\n        $global:__zoxide_oldpwd = $result\n    }\n}\n{%- endif %}\n\n# Initialize hook.\n$global:__zoxide_hooked = (Get-Variable __zoxide_hooked -ErrorAction Ignore -ValueOnly)\nif ($global:__zoxide_hooked -ne 1) {\n    $global:__zoxide_hooked = 1\n    $global:__zoxide_prompt_old = $function:prompt\n\n    function global:prompt {\n        if ($null -ne $__zoxide_prompt_old) {\n            & $__zoxide_prompt_old'
        '\n        }\n        $null = __zoxide_hook\n    }\n}\n{%- endif %}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\nfunction global:__zoxide_z {\n    if ($args.Length -eq 0) {\n        __zoxide_cd $null $true\n    }\n    elseif ($args.Length -eq 1 -and ($args[0] -eq \'-\' -or $args[0] -eq \'+\')) {\n        __zoxide_cd $args[0] $false\n    }\n    elseif ($args.Length -eq 1 -and (Test-Path -PathType Container -LiteralPath $args[0])) {\n        __zoxide_cd $args[0] $true\n    }\n    elseif ($args.Length -eq 1 -and (Test-Path -PathType Container -Path $args[0] )) {\n        __zoxide_cd $args[0] $false\n    }\n    else {\n        $result = __zoxide_pwd\n        if ($null -ne $result) {\n            $result = __zoxide_bin query --exclude $result "--" @args\n        }\n        else {\n            $result = __zoxide_bin query "--" @a'
        'rgs\n        }\n        if ($LASTEXITCODE -eq 0) {\n            __zoxide_cd $result $true\n        }\n    }\n}\n\n# Jump to a directory using interactive search.\nfunction global:__zoxide_zi {\n    $result = __zoxide_bin query -i "--" @args\n    if ($LASTEXITCODE -eq 0) {\n        __zoxide_cd $result $true\n    }\n}\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nSet-Alias -Name {{cmd}} -Value __zoxide_z -Option AllScope -Scope Global -Force\nSet-Alias -Name {{cmd}}i -Value __zoxide_zi -Option AllScope -Scope Global -Force\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your configuration (find it by running\n# `echo $profile` in PowerShell):\n#\n# Invoke-Expression (& { (zoxide init powershell | Out-String) })\n'
    ),
    'tcsh': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n{%- let pwd_cmd -%}\n{%- if resolve_symlinks -%}\n{%- let pwd_cmd = "pwd -P" -%}\n{%- else -%}\n{%- let pwd_cmd = "pwd -L" -%}\n{%- endif -%}\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n{%- if hook != InitHook::None %}\n\n# Hook to add new entries to the database.\n{%- if hook == InitHook::Prompt %}\nalias __zoxide_hook \'zoxide add -- "`{{ pwd_cmd }}`"\'\n\n{%- else if hook == InitHook::Pwd %}\nset __zoxide_pwd_old = `{{ pwd_cmd }}`\nalias __zoxide_hook \'set __zoxide_pwd_tmp = "`{{ pwd_cmd }}`"; test "$__zoxide_pwd_tmp" != "$__zoxide_pwd_old" && zoxide add -- "$__zoxide_pwd_tmp"; set __zoxide_pwd_old = "$__zoxide_pwd_tmp"\'\n{%- endif %}\n\n# Initialize hook.\nalias precmd \';__zoxide_hook\'\n\n{%- endif %}\n\n{{ section }}\n# When using zoxide wit'
        'h --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\nalias __zoxide_z \'set __zoxide_args = (\\!*)\\\nif ("$#__zoxide_args" == 0) then\\\n    cd ~\\\nelse\\\n    if ("$#__zoxide_args" == 1 && "$__zoxide_args[1]" == "-") then\\\n        cd -\\\n    else if ("$#__zoxide_args" == 1 && -d "$__zoxide_args[1]") then\\\n        cd "$__zoxide_args[1]"\\\n    else\\\n        set __zoxide_pwd = `{{ pwd_cmd }}`\\\n        set __zoxide_result = "`zoxide query --exclude \'"\'"\'$__zoxide_pwd\'"\'"\' -- $__zoxide_args`" && cd "$__zoxide_result"\\\n    endif\\\nendif\'\n\n# Jump to a directory using interactive search.\nalias __zoxide_zi \'set __zoxide_args = (\\!*)\\\nset __zoxide_pwd = `{{ pwd_cmd }}`\\\nset __zoxide_result = "`zoxide query --exclude \'"\'"\'$__zoxide_pwd\'"\'"\' --interactive -- $__zoxide_args`" && cd "$__zoxide_result"\'\n\n{{ section }}\n# Commands for zoxide. Disable these using --no'
        '-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nalias {{cmd}} __zoxide_z\nalias {{cmd}}i __zoxide_zi\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your shell configuration file (usually ~/.tcshrc):\n#\n#     zoxide init tcsh > ~/.zoxide.tcsh\n#     source ~/.zoxide.tcsh\n'
    ),
    'xonsh': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n# pylint: disable=missing-module-docstring\n\nimport builtins  # pylint: disable=unused-import\nimport os\nimport os.path\nimport subprocess\nimport sys\nimport typing\n\nimport xonsh.dirstack  # type: ignore # pylint: disable=import-error\nimport xonsh.environ  # type: ignore # pylint: disable=import-error\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n\ndef __zoxide_bin() -> str:\n    """Finds and returns the location of the zoxide binary."""\n    zoxide = typing.cast(str, xonsh.environ.locate_binary("zoxide"))\n    if zoxide is None:\n        zoxide = "zoxide"\n    return zoxide\n\n\ndef __zoxide_env() -> dict[str, str]:\n    """Returns the current environment."""\n    return builtins.__xonsh__.env.detype()  # type: ignore  # pylint:disable=no'
        '-member\n\n\ndef __zoxide_pwd() -> str:\n    """pwd based on the value of _ZO_RESOLVE_SYMLINKS."""\n{%- if resolve_symlinks %}\n    pwd = os.getcwd()\n{%- else %}\n    pwd = __zoxide_env().get("PWD")\n    if pwd is None:\n        raise RuntimeError("$PWD not found")\n{%- endif %}\n    return pwd\n\n\ndef __zoxide_cd(path: str | bytes | None = None) -> None:\n    """cd + custom logic based on the value of _ZO_ECHO."""\n    if path is None:\n        args = []\n    elif isinstance(path, bytes):\n        args = [path.decode("utf-8")]\n    else:\n        args = [path]\n    _, exc, _ = xonsh.dirstack.cd(args)\n    if exc is not None:\n        raise RuntimeError(exc)\n{%- if echo %}\n    print(__zoxide_pwd())\n{%- endif %}\n\n\nclass ZoxideSilentException(Exception):\n    """Exit without complaining."""\n\n\ndef __zoxide_errhandler(\n    func: typing.Callable[[list[str]], None],\n) -> typing.Callable[[list[str]], int]:\n    """Prin'
        't exception and exit with error code 1."""\n\n    def wrapper(args: list[str]) -> int:\n        try:\n            func(args)\n            return 0\n        except ZoxideSilentException:\n            return 1\n        except Exception as exc:  # pylint: disable=broad-except\n            print(f"zoxide: {exc}", file=sys.stderr)\n            return 1\n\n    return wrapper\n\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n{% if hook == InitHook::None -%}\n{{ not_configured }}\n\n{%- else -%}\n# Initialize hook to add new entries to the database.\nif "__zoxide_hook" not in globals():\n{% if hook == InitHook::Prompt %}\n    @builtins.events.on_post_prompt  # type: ignore  # pylint:disable=no-member\n{%- else if hook == InitHook::Pwd %}\n    @builtins.events.on_chdir  # type: ignore  # pylint:disable=no-member\n{%- endif %}\n    def __zoxide_hook(**_kwargs: typing.Any) -> None:\n        """Hook to add new entries to'
        ' the database."""\n        pwd = __zoxide_pwd()\n        zoxide = __zoxide_bin()\n        subprocess.run(\n            [zoxide, "add", "--", pwd],\n            check=False,\n            env=__zoxide_env(),\n        )\n{% endif %}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n\n@__zoxide_errhandler\ndef __zoxide_z(args: list[str]) -> None:\n    """Jump to a directory using only keywords."""\n    if args == []:\n        __zoxide_cd()\n    elif args == ["-"]:\n        __zoxide_cd("-")\n    elif len(args) == 1 and os.path.isdir(args[0]):\n        __zoxide_cd(args[0])\n    else:\n        try:\n            zoxide = __zoxide_bin()\n            cmd = subprocess.run(\n                [zoxide, "query", "--exclude", __zoxide_pwd(), "--"] + args,\n                check=True,\n                env=__zoxide_env(),\n                stdout=subprocess.PIPE,\n            )\n        e'
        'xcept subprocess.CalledProcessError as exc:\n            raise ZoxideSilentException() from exc\n\n        result = cmd.stdout[:-1]\n        __zoxide_cd(result)\n\n\n@__zoxide_errhandler\ndef __zoxide_zi(args: list[str]) -> None:\n    """Jump to a directory using interactive search."""\n    try:\n        zoxide = __zoxide_bin()\n        cmd = subprocess.run(\n            [zoxide, "query", "-i", "--"] + args,\n            check=True,\n            env=__zoxide_env(),\n            stdout=subprocess.PIPE,\n        )\n    except subprocess.CalledProcessError as exc:\n        raise ZoxideSilentException() from exc\n\n    result = cmd.stdout[:-1]\n    __zoxide_cd(result)\n\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nbuiltins.aliases["{{cmd}}"] = __zoxide_z  # type: ignore  # pylint:disable=no-member\nbuiltins.aliases["{{cmd}}i"] = __zoxide_zi  # '
        "type: ignore  # pylint:disable=no-member\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n{{ section }}\n# To initialize zoxide, add this to your configuration (usually ~/.xonshrc):\n#\n# execx($(zoxide init xonsh), 'exec', __xonsh__.ctx, filename='zoxide')\n"
    ),
    'zsh': (
        '{%- let section = "# =============================================================================\\n#" -%}\n{%- let not_configured = "# -- not configured --" -%}\n\n# shellcheck shell=bash\n\n{{ section }}\n# Utility functions for zoxide.\n#\n\n# pwd based on the value of _ZO_RESOLVE_SYMLINKS.\nfunction __zoxide_pwd() {\n{%- let pwd -%}\n{%- if resolve_symlinks -%}\n{%- let pwd = "\\\\builtin pwd -P" -%}\n{%- else -%}\n{%- let pwd = "\\\\builtin pwd -L" -%}\n{%- endif -%}\n{%- if cfg!(windows) %}\n    \\command cygpath -w "{{ pwd }}"\n{%- else %}\n    {{ pwd }}\n{%- endif %}\n}\n\n# cd + custom logic based on the value of _ZO_ECHO.\nfunction __zoxide_cd() {\n    # shellcheck disable=SC2164\n    \\builtin cd -- "$@" {%- if echo %} && __zoxide_pwd {%- endif %}\n}\n\n{{ section }}\n# Hook configuration for zoxide.\n#\n\n# Hook to add new entries to the database.\nfunction __zoxide_hook() {\n    # shellcheck disable=SC2312\n    \\comm'
        'and zoxide add -- "$(__zoxide_pwd)"\n}\n\n# Initialize hook.\n\\builtin typeset -ga precmd_functions\n\\builtin typeset -ga chpwd_functions\n# shellcheck disable=SC2034,SC2296\nprecmd_functions=("${(@)precmd_functions:#__zoxide_hook}")\n# shellcheck disable=SC2034,SC2296\nchpwd_functions=("${(@)chpwd_functions:#__zoxide_hook}")\n\n{%- if hook == InitHook::Prompt %}\nprecmd_functions+=(__zoxide_hook)\n{%- else if hook == InitHook::Pwd %}\nchpwd_functions+=(__zoxide_hook)\n{%- endif %}\n\n# Report common issues.\nfunction __zoxide_doctor() {\n{%- if hook == InitHook::None %}\n    return 0\n\n{%- else %}\n    [[ ${_ZO_DOCTOR:-1} -ne 0 ]] || return 0\n\n{%- if hook == InitHook::Prompt %}\n    [[ ${precmd_functions[(Ie)__zoxide_hook]:-} -eq 0 ]] || return 0\n{%- else if hook == InitHook::Pwd %}\n    [[ ${chpwd_functions[(Ie)__zoxide_hook]:-} -eq 0 ]] || return 0\n{%- endif %}\n\n    _ZO_DOCTOR=0\n    \\builtin printf \'%s\\n\' \\\n'
        '        \'zoxide: detected a possible configuration issue.\' \\\n        \'Please ensure that zoxide is initialized right at the end of your shell configuration file (usually ~/.zshrc).\' \\\n        \'\' \\\n        \'If the issue persists, consider filing an issue at:\' \\\n        \'https://github.com/ajeetdsouza/zoxide/issues\' \\\n        \'\' \\\n        \'Disable this message by setting _ZO_DOCTOR=0.\' \\\n        \'\' >&2\n{%- endif %}\n}\n\n{{ section }}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n# Jump to a directory using only keywords.\nfunction __zoxide_z() {\n    __zoxide_doctor\n    if [[ "$#" -eq 0 ]]; then\n        __zoxide_cd ~\n    elif [[ "$#" -eq 1 ]] && { [[ -d "$1" ]] || [[ "$1" = \'-\' ]] || [[ "$1" =~ ^[-+][0-9]+$ ]]; }; then\n        __zoxide_cd "$1"\n    elif [[ "$#" -eq 2 ]] && [[ "$1" = "--" ]]; then\n        __zoxide_cd "$2"\n    else\n        \\builtin local result\n'
        '        # shellcheck disable=SC2312\n        result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" && __zoxide_cd "${result}"\n    fi\n}\n\n# Jump to a directory using interactive search.\nfunction __zoxide_zi() {\n    __zoxide_doctor\n    \\builtin local result\n    result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "${result}"\n}\n\n{{ section }}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n{%- match cmd %}\n{%- when Some with (cmd) %}\n\nfunction {{ cmd }}() {\n    __zoxide_z "$@"\n}\n\nfunction {{ cmd }}i() {\n    __zoxide_zi "$@"\n}\n\n{%- when None %}\n\n{{ not_configured }}\n\n{%- endmatch %}\n\n# Completions.\nif [[ -o zle ]]; then\n    __zoxide_result=\'\'\n\n    function __zoxide_z_complete() {\n        # Only show completions when the cursor is at the end of the line.\n        # shellcheck disable=SC2154\n        [[ "{{ "${#words[@]}" }}" -eq "${CURRENT}" ]] || return '
        '0\n\n        if [[ "{{ "${#words[@]}" }}" -eq 2 ]]; then\n            # Show completions for local directories.\n            _cd -/\n\n        elif [[ "${words[-1]}" == \'\' ]]; then\n            # Show completions for Space-Tab.\n            # shellcheck disable=SC2086\n            __zoxide_result="$(\\command zoxide query --exclude "$(__zoxide_pwd || \\builtin true)" --interactive -- ${words[2,-1]})" || __zoxide_result=\'\'\n\n            # Set a result to ensure completion doesn\'t re-run\n            compadd -Q ""\n\n            # Bind \'\\e[0n\' to helper function.\n            \\builtin bindkey \'\\e[0n\' \'__zoxide_z_complete_helper\'\n            # Sends query device status code, which results in a \'\\e[0n\' being sent to console input.\n            \\builtin printf \'\\e[5n\'\n\n            # Report that the completion was successful, so that we don\'t fall back\n            # to another completion function.\n            '
        'return 0\n        fi\n    }\n\n    function __zoxide_z_complete_helper() {\n        if [[ -n "${__zoxide_result}" ]]; then\n            # shellcheck disable=SC2034,SC2296\n            BUFFER="{{ cmd.unwrap_or("cd") }} ${(q-)__zoxide_result}"\n            __zoxide_result=\'\'\n            \\builtin zle reset-prompt\n            \\builtin zle accept-line\n        else\n            \\builtin zle reset-prompt\n        fi\n    }\n    \\builtin zle -N __zoxide_z_complete_helper\n{%- if let Some(cmd) = cmd %}\n\n    [[ "${+functions[compdef]}" -ne 0 ]] && \\compdef __zoxide_z_complete {{ cmd }}\n{%- endif %}\nfi\n\n{{ section }}\n# To initialize zoxide, add this to your shell configuration file (usually ~/.zshrc):\n#\n# eval "$(zoxide init zsh)"\n'
    ),
}

MAIN_HELP = """zoxide 0.9.9
Ajeet D'Souza <98ajeet@gmail.com>
https://github.com/ajeetdsouza/zoxide

A smarter cd command for your terminal

Usage:
  executable <COMMAND>

Commands:
  add     Add a new directory or increment its rank
  edit    Edit the database
  import  Import entries from another application
  init    Generate shell configuration
  query   Search for a directory in the database
  remove  Remove a directory from the database

Options:
  -h, --help     Print help
  -V, --version  Print version

Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths
"""

SUBCOMMANDS = {
    "add": ("Add a new directory or increment its rank", "executable add [OPTIONS] <PATHS>..."),
    "edit": ("Edit the database", "executable edit [COMMAND] [PATH]"),
    "import": ("Import entries from another application", "executable import [OPTIONS] --from <FROM> <PATH>"),
    "init": ("Generate shell configuration", "executable init [OPTIONS] <SHELL>"),
    "query": ("Search for a directory in the database", "executable query [OPTIONS] [KEYWORDS]..."),
    "remove": ("Remove a directory from the database", "executable remove [PATHS]..."),
}

ENV_HELP = [
    "  _ZO_DATA_DIR          Path for zoxide data files",
    "  _ZO_ECHO              Print the matched directory before navigating to it when set to 1",
    "  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded",
    "  _ZO_FZF_OPTS          Custom flags to pass to fzf",
    "  _ZO_MAXAGE            Maximum total age after which entries start getting deleted",
    "  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths",
]


class ZoxideError(Exception):
    pass


class UsageExit(Exception):
    def __init__(self, code):
        self.code = code


def eprint(text=""):
    sys.stderr.write(str(text) + "\n")


def zoxide_error(message):
    eprint(f"zoxide: {message}")
    return 1


def usage_error(message, usage):
    eprint(f"error: {message}")
    eprint()
    eprint(f"Usage: {usage}")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def simple_error(message):
    eprint(f"error: {message}")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def invalid_value_error(value, flag, values):
    eprint(f"error: invalid value '{value}' for '{flag}'")
    eprint(f"  [possible values: {values}]")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def unexpected_arg_error(arg, usage, tip=True):
    eprint(f"error: unexpected argument '{arg}' found")
    eprint()
    if tip:
        eprint(f"  tip: to pass '{arg}' as a value, use '-- {arg}'")
        eprint()
    eprint(f"Usage: {usage}")
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def sub_help(command):
    about, usage = SUBCOMMANDS[command]
    lines = [
        f"zoxide-{command} 0.9.9",
        "Ajeet D'Souza <98ajeet@gmail.com>",
        "https://github.com/ajeetdsouza/zoxide",
        "",
        about,
        "",
        "Usage:",
        f"  {usage}",
        "",
    ]
    if command == "add":
        lines += [
            "Arguments:",
            "  <PATHS>...  ",
            "",
            "Options:",
            "  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't",
            "  -h, --help           Print help",
            "  -V, --version        Print version",
        ]
    elif command == "query":
        lines += [
            "Arguments:",
            "  [KEYWORDS]...  ",
            "",
            "Options:",
            "  -a, --all              Show unavailable directories",
            "  -i, --interactive      Use interactive selection",
            "  -l, --list             List all matching directories",
            "  -s, --score            Print score with results",
            "      --exclude <path>   Exclude the current directory",
            "      --base-dir <path>  Only search within this directory",
            "  -h, --help             Print help",
            "  -V, --version          Print version",
        ]
    elif command == "init":
        lines += [
            "Arguments:",
            "  <SHELL>  [possible values: bash, elvish, fish, ksh, nushell, posix, powershell, tcsh, xonsh, zsh]",
            "",
            "Options:",
            "      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands",
            "      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]",
            "      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]",
        ]
    elif command == "import":
        lines += [
            "Arguments:",
            "  <PATH>  ",
            "",
            "Options:",
            "      --from <FROM>  Application to import from [possible values: autojump, z]",
            "      --merge        Merge into existing database",
        ]
    elif command == "remove":
        lines += ["Arguments:", "  [PATHS]...  ", "", "Options:"]
    else:
        lines += ["Options:"]
    if command not in {"add", "query"}:
        lines += ["  -h, --help     Print help", "  -V, --version  Print version"]
    lines += ["", "Environment variables:", *ENV_HELP]
    return "\n".join(lines) + "\n"


def data_dir():
    value = os.environ.get("_ZO_DATA_DIR")
    if value:
        if not os.path.isabs(value):
            raise ZoxideError("_ZO_DATA_DIR must be an absolute path")
        return value
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "zoxide")


def db_path():
    return os.path.join(data_dir(), "db.zo")


def parse_maxage():
    raw = os.environ.get("_ZO_MAXAGE", "10000")
    text = raw
    try:
        if not text or any(ch not in "0123456789" for ch in text):
            raise ValueError
        value = int(text)
        if value < 0 or value > 0xFFFFFFFF:
            raise ValueError
    except ValueError:
        raise ZoxideError(f"unable to parse _ZO_MAXAGE as integer: {raw}\n\nCaused by:\n    invalid digit found in string")
    return float(value)


def validate_exclude_patterns():
    raw = os.environ.get("_ZO_EXCLUDE_DIRS", "")
    for pattern in [p for p in raw.split(os.pathsep) if p]:
        if pattern.count("[") != pattern.count("]"):
            raise ZoxideError(f"invalid glob in _ZO_EXCLUDE_DIRS: {pattern}\n\nCaused by:\n    Pattern syntax error")


def load_db():
    path = db_path()
    if not os.path.exists(path):
        return []
    data = open(path, "rb").read()
    if not data:
        return []
    version = int.from_bytes(data[:4].ljust(4, b"\0"), "little")
    if version != DB_VERSION:
        raise ZoxideError(f"could not open database: unsupported version (got {version}, supports 3)")
    payload = data[4:]
    if not payload:
        return []
    try:
        decoded = json.loads(payload.decode("utf-8"))
    except Exception as exc:
        raise ZoxideError(f"could not open database: invalid data: {exc}")
    rows = []
    for index, row in enumerate(decoded if isinstance(decoded, list) else []):
        if not isinstance(row, dict) or not row.get("path"):
            continue
        rows.append(
            {
                "path": str(row["path"]),
                "rank": max(0.0, float(row.get("rank", row.get("score", 0.0)))),
                "last_access": float(row.get("last_access", 0.0)),
                "order": int(row.get("order", index)),
            }
        )
    return rows


def save_db(rows):
    directory = data_dir()
    os.makedirs(directory, exist_ok=True)
    payload = json.dumps(rows, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    tmp = db_path() + ".tmp"
    with open(tmp, "wb") as handle:
        handle.write(DB_VERSION.to_bytes(4, "little"))
        handle.write(payload)
    os.replace(tmp, db_path())


def recency_multiplier(row):
    age = max(0.0, time.time() - float(row.get("last_access", 0.0)))
    if age < 3600:
        return 4.0
    if age < 86400:
        return 2.0
    if age < 604800:
        return 0.5
    return 0.25


def display_score(row):
    return min(9999.0, max(0.0, float(row.get("rank", 0.0)) * recency_multiplier(row)))


def apply_aging(rows):
    maxage = parse_maxage()
    total = sum(max(0.0, float(row.get("rank", 0.0))) for row in rows)
    if maxage == 0 and total > 0:
        return []
    if total > maxage:
        factor = 0.9 * maxage / total
        aged = []
        for row in rows:
            row = dict(row)
            row["rank"] = max(0.0, row["rank"] * factor)
            if row["rank"] >= 1.0:
                aged.append(row)
        return aged
    return rows


def norm_path(path):
    path = os.path.expanduser(path)
    if os.environ.get("_ZO_RESOLVE_SYMLINKS") == "1":
        return os.path.realpath(path)
    return os.path.abspath(os.path.normpath(path))


def has_excluded_chars(path):
    return "\n" in path or "\r" in path


def excluded(path):
    validate_exclude_patterns()
    raw = os.environ.get("_ZO_EXCLUDE_DIRS", "")
    for pattern in [p for p in raw.split(os.pathsep) if p]:
        expanded = os.path.expanduser(pattern)
        if fnmatch.fnmatch(path, expanded) or fnmatch.fnmatch(os.path.basename(path), expanded):
            return True
    return False


def next_order(rows):
    return (max([row.get("order", -1) for row in rows] or [-1]) + 1)


def upsert(rows, path, rank_delta, last_access=None):
    if last_access is None:
        last_access = time.time()
    for row in rows:
        if row["path"] == path:
            row["rank"] = max(0.0, float(row.get("rank", 0.0)) + rank_delta)
            row["last_access"] = max(float(row.get("last_access", 0.0)), float(last_access))
            return
    rows.append({"path": path, "rank": max(0.0, rank_delta), "last_access": float(last_access), "order": next_order(rows)})


def parse_value(argv, i, flag, usage):
    if i + 1 >= len(argv) or argv[i + 1] == "":
        raise UsageExit(usage_error(f"a value is required for '{flag}' but none was supplied", usage))
    return argv[i + 1], i + 2


def parse_float(value, flag, usage):
    try:
        return float(value)
    except ValueError:
        raise UsageExit(simple_error(f"invalid value '{value}' for '{flag}': invalid float literal"))


def output_query_rows(rows, score_mode):
    for row in rows:
        if score_mode:
            sys.stdout.write(f"{display_score(row):6.1f} {row['path']}\n")
        else:
            sys.stdout.write(row["path"] + "\n")


def output_edit_rows(rows):
    for row in sorted(rows, key=lambda item: item.get("order", 0), reverse=True):
        sys.stdout.write(f"{display_score(row):6.1f}\t{row['path']}\0")


def command_preamble():
    parse_maxage()
    validate_exclude_patterns()


def cmd_add(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(sub_help("add"))
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write(VERSION)
        return 0
    command_preamble()
    score = 1.0
    saw_score = False
    paths = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            paths.extend(argv[i + 1:])
            break
        if arg in ("-s", "--score"):
            if saw_score:
                return usage_error("the argument '--score <SCORE>' cannot be used multiple times", "executable add [OPTIONS] <PATHS>...")
            saw_score = True
            value, i = parse_value(argv, i, "--score <SCORE>", "executable add [OPTIONS] <PATHS>...")
            score = parse_float(value, "--score <SCORE>", "executable add [OPTIONS] <PATHS>...")
            continue
        if arg.startswith("--score="):
            if saw_score:
                return usage_error("the argument '--score <SCORE>' cannot be used multiple times", "executable add [OPTIONS] <PATHS>...")
            saw_score = True
            score = parse_float(arg.split("=", 1)[1], "--score <SCORE>", "executable add [OPTIONS] <PATHS>...")
            i += 1
            continue
        if arg.startswith("-"):
            return unexpected_arg_error(arg, "executable add [OPTIONS] <PATHS>...")
        paths.append(arg)
        i += 1
    if not paths:
        return usage_error("the following required arguments were not provided:\n  <PATHS>...", "executable add <PATHS>...")
    if any(path == "" for path in paths):
        return simple_error("a value is required for '<PATHS>...' but none was supplied")
    normalized = []
    for raw in paths:
        if has_excluded_chars(raw):
            continue
        path = norm_path(raw)
        if excluded(path):
            continue
        if not os.path.isdir(path):
            return zoxide_error(f"not a directory: {path}")
        normalized.append(path)
    rows = load_db()
    for path in normalized:
        upsert(rows, path, score, time.time())
    rows = apply_aging(rows)
    save_db(rows)
    return 0


def keyword_match(path, keywords, strict_last=True):
    keys = [key for key in keywords if key != ""]
    if not keys:
        return True
    text = path.replace("\\", "/").lower()
    normalized = [key.replace("\\", "/").lower() for key in keys]
    last_key = normalized[-1]
    idx = text.rfind(last_key)
    if idx < 0:
        return False
    if strict_last and "/" in text[idx + len(last_key):]:
        return False
    text = text[:idx]
    for key in reversed(normalized[:-1]):
        idx = text.rfind(key)
        if idx < 0:
            return False
        text = text[:idx]
    return True


def matching_rows(rows, keywords, show_all, exclude_path, base_dir, strict_last=True):
    visible = list(rows)
    before_exclude = [row for row in visible if keyword_match(row["path"], keywords, strict_last=strict_last)]
    if exclude_path:
        ex = norm_path(exclude_path)
        visible = [row for row in visible if norm_path(row["path"]) != ex]
    if base_dir:
        base = norm_path(base_dir)
        visible = [row for row in visible if norm_path(row["path"]).startswith(base)]
    visible = [row for row in visible if not excluded(row["path"])]
    if not show_all:
        visible = [row for row in visible if os.path.isdir(row["path"])]
    matched = [row for row in visible if keyword_match(row["path"], keywords, strict_last=strict_last)]
    matched.sort(key=lambda row: (-display_score(row), -row.get("rank", 0.0), len(row["path"]), row["path"]))
    return before_exclude, matched


def cmd_query(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(sub_help("query"))
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write(VERSION)
        return 0
    command_preamble()
    show_all = False
    interactive = False
    list_mode = False
    score_mode = False
    exclude_path = None
    base_dir = None
    keywords = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--":
            keywords.extend(argv[i + 1:])
            break
        if arg in ("-a", "--all"):
            show_all = True
        elif arg in ("-i", "--interactive"):
            interactive = True
        elif arg in ("-l", "--list"):
            list_mode = True
        elif arg in ("-s", "--score"):
            score_mode = True
        elif arg == "--exclude":
            exclude_path, i = parse_value(argv, i, "--exclude <path>", "executable query [OPTIONS] [KEYWORDS]...")
            continue
        elif arg.startswith("--exclude="):
            exclude_path = arg.split("=", 1)[1]
        elif arg == "--base-dir":
            base_dir, i = parse_value(argv, i, "--base-dir <path>", "executable query [OPTIONS] [KEYWORDS]...")
            continue
        elif arg.startswith("--base-dir="):
            base_dir = arg.split("=", 1)[1]
        elif arg.startswith("-"):
            return unexpected_arg_error(arg, "executable query [OPTIONS] [KEYWORDS]...")
        else:
            keywords.append(arg)
        i += 1
    if interactive and list_mode:
        return usage_error("the argument '--interactive' cannot be used with '--list'", "executable query --interactive [KEYWORDS]...")
    rows = apply_aging(load_db())
    save_db(rows)
    before_exclude, rows = matching_rows(rows, keywords, show_all, exclude_path, base_dir, strict_last=not interactive)
    if interactive:
        return run_interactive(rows, score_mode)
    if not rows:
        if list_mode:
            return 0
        if exclude_path and before_exclude:
            return zoxide_error("you are already in the only match")
        return zoxide_error("no match found")
    output_query_rows(rows if list_mode else rows[:1], score_mode)
    return 0


def run_interactive(rows, score_mode):
    fzf = shutil.which("fzf")
    if not fzf:
        return zoxide_error("could not find fzf, is it installed?")
    if not rows:
        return zoxide_error("no match found")
    args = [fzf, "--exact", "--no-sort", "--exit-0", "--delimiter=\t", "--nth=2", "--read0"]
    if os.name != "nt":
        args.append("--preview=echo {2}")
    custom = os.environ.get("_ZO_FZF_OPTS")
    if custom:
        args.extend(custom.split())
    feed = "".join(f"{display_score(row):.4f}\t{row['path']}\0" for row in rows)
    proc = subprocess.run(args, input=feed, capture_output=True, text=True)
    if proc.returncode == 130:
        return 130
    if proc.returncode == 1:
        return zoxide_error("no match found")
    if proc.returncode == 2:
        return zoxide_error("fzf returned an error")
    if 128 <= proc.returncode <= 254:
        return zoxide_error("fzf was terminated")
    selection = proc.stdout
    if not selection or "\t" not in selection or len(selection) < 7:
        return zoxide_error("could not read selection from fzf")
    if score_mode:
        sys.stdout.write(selection)
    else:
        sys.stdout.write(selection.split("\t", 1)[1])
    return 0


def cmd_remove(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(sub_help("remove"))
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write(VERSION)
        return 0
    command_preamble()
    paths = []
    for arg in argv:
        if arg == "--":
            continue
        if arg.startswith("-"):
            return unexpected_arg_error(arg, "executable remove [PATHS]...")
        paths.append(norm_path(arg))
    if not paths:
        return 0
    rows = load_db()
    existing = {row["path"] for row in rows}
    seen = set()
    for path in paths:
        if path in seen or path not in existing:
            return zoxide_error(f"path not found in database: {path}")
        seen.add(path)
    rows = [row for row in rows if row["path"] not in seen]
    save_db(rows)
    return 0


def init_template_source(shell):
    if shell == "ksh":
        shell = "posix"
    names = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", f"{shell}.txt"),
        os.path.join(os.getcwd(), "templates", f"{shell}.txt"),
    ]
    for path in names:
        if os.path.exists(path):
            return open(path, "r", encoding="utf-8").read()
    return FALLBACK_TEMPLATES.get(shell)


def template_tokens(source):
    i = 0
    while i < len(source):
        start = i
        while True:
            start = source.find("{", start)
            if start < 0 or start + 1 >= len(source):
                break
            if source[start + 1] in "{%#":
                break
            start += 1
        if start < 0 or start + 1 >= len(source):
            yield "text", source[i:]
            return
        marker = source[start + 1]
        if start > i:
            yield "text", source[i:start]
        close = {"{": "}}", "%": "%}", "#": "#}"}[marker]
        if marker == "{":
            end = start + 2
            quoted = False
            escaped = False
            while end < len(source) - 1:
                char = source[end]
                if escaped:
                    escaped = False
                elif char == "\\" and quoted:
                    escaped = True
                elif char == '"':
                    quoted = not quoted
                elif not quoted and source.startswith(close, end):
                    break
                end += 1
            end = end if end < len(source) - 1 else -1
        else:
            end = source.find(close, start + 2)
        if end < 0:
            yield "text", source[start:]
            return
        token = source[start:end + 2]
        i = end + 2
        yield marker, token


def strip_template_token(token, marker):
    left_trim = token.startswith("{{-") or token.startswith("{%-") or token.startswith("{#-")
    right_trim = token.endswith("-}}") or token.endswith("-%}") or token.endswith("-#}")
    left = 3 if left_trim else 2
    right = -3 if right_trim else -2
    return token[left:right].strip(), left_trim, right_trim


def hook_name(value):
    return {"none": "None", "prompt": "Prompt", "pwd": "Pwd"}.get(value, value)


def eval_template_expr(expr, ctx):
    expr = expr.strip()
    if expr in ctx:
        value = ctx[expr]
        return "" if value is None else str(value)
    if expr.startswith('"') and expr.endswith('"'):
        try:
            return str(ast.literal_eval(expr))
        except Exception:
            return expr[1:-1]
    match = re.fullmatch(r'cmd\.unwrap_or\("([^"]*)"\)', expr)
    if match:
        return str(ctx.get("cmd") or match.group(1))
    return ""


def eval_template_condition(expr, ctx):
    expr = expr.strip()
    if expr == "echo":
        return bool(ctx.get("echo"))
    if expr == "resolve_symlinks":
        return bool(ctx.get("resolve_symlinks"))
    if expr == "cfg!(windows)":
        return False
    if expr == "cmd":
        return ctx.get("cmd") is not None
    match = re.fullmatch(r"hook\s*([!=]=)\s*InitHook::(\w+)", expr)
    if match:
        current = hook_name(str(ctx.get("hook")))
        wanted = match.group(2)
        return (current == wanted) if match.group(1) == "==" else (current != wanted)
    if expr == "let Some(cmd) = cmd":
        return ctx.get("cmd") is not None
    return False


def render_init_template(source, cmd, hook, echo, resolve_symlinks):
    ctx = {
        "cmd": cmd,
        "hook": hook,
        "echo": echo,
        "resolve_symlinks": resolve_symlinks,
    }
    out = ""
    trim_next = False
    stack = []

    def active():
        return all(frame["active"] for frame in stack)

    for marker, token in template_tokens(source):
        if marker == "text":
            text = token
            if trim_next:
                text = re.sub(r"^[ \t\r\n]+", "", text)
                trim_next = False
            if active():
                out += text
            continue

        expr, left_trim, right_trim = strip_template_token(token, marker)
        if left_trim and active():
            out = out.rstrip(" \t\r\n")
        if marker == "#":
            trim_next = right_trim
            continue
        if marker == "{":
            if active():
                out += eval_template_expr(expr, ctx)
            trim_next = right_trim
            continue

        parent_active = active()
        if expr.startswith("let "):
            if parent_active:
                match = re.fullmatch(r"let\s+(\w+)(?:\s*=\s*(.*))?", expr, re.DOTALL)
                if match:
                    name, value = match.group(1), match.group(2)
                    ctx[name] = eval_template_expr(value, ctx) if value is not None else ctx.get(name, "")
        elif expr.startswith("if "):
            cond = expr[3:].strip()
            value = parent_active and eval_template_condition(cond, ctx)
            stack.append({"kind": "if", "parent": parent_active, "active": value, "taken": value})
        elif expr.startswith("else if "):
            frame = stack[-1]
            cond = expr[8:].strip()
            value = frame["parent"] and not frame["taken"] and eval_template_condition(cond, ctx)
            frame["active"] = value
            frame["taken"] = frame["taken"] or value
        elif expr == "else":
            frame = stack[-1]
            frame["active"] = frame["parent"] and not frame["taken"]
            frame["taken"] = True
        elif expr == "endif":
            stack.pop()
        elif expr.startswith("match "):
            name = expr[6:].strip()
            value = ctx.get(name)
            stack.append({"kind": "match", "parent": parent_active, "active": False, "taken": False, "value": value})
        elif expr.startswith("when "):
            frame = stack[-1]
            choice = expr[5:].strip()
            value = False
            if choice.startswith("Some"):
                value = frame["value"] is not None
            elif choice == "None":
                value = frame["value"] is None
            elif choice.startswith("InitHook::"):
                value = hook_name(str(frame["value"])) == choice.split("::", 1)[1]
            frame["active"] = frame["parent"] and not frame["taken"] and value
            frame["taken"] = frame["taken"] or frame["active"]
        elif expr == "endmatch":
            stack.pop()
        trim_next = right_trim
    return out.replace("\n## Hook to add new entries to the database.", "\n#\n\n# Hook to add new entries to the database.")


def shell_script(shell, cmd="z", hook="pwd", no_cmd=False):
    if shell == "ksh":
        shell = "posix"
    source = init_template_source(shell)
    if source:
        rendered = render_init_template(
            source,
            None if no_cmd else cmd,
            hook,
            os.environ.get("_ZO_ECHO") == "1",
            os.environ.get("_ZO_RESOLVE_SYMLINKS") == "1",
        )
        return rendered if rendered.endswith("\n") else rendered + "\n"
    zi = cmd + "i"
    section = "# =============================================================================\n#"
    not_configured = "# -- not configured --"
    if shell in ("bash", "zsh", "posix"):
        bashish = shell != "posix"
        fn = "function " if bashish else ""
        body = "# shellcheck shell=bash\n\n" if bashish else "# shellcheck shell=sh\n\n"
        body += f"{section}\n# Utility functions for zoxide.\n#\n\n"
        pwd = "\\builtin pwd -P" if os.environ.get("_ZO_RESOLVE_SYMLINKS") == "1" else "\\builtin pwd -L"
        body += f"{fn}__zoxide_pwd() {{\n    {pwd}\n}}\n\n"
        body += f"{fn}__zoxide_cd() {{\n    \\builtin cd -- \"$@\"\n}}\n\n"
        body += f"{section}\n# Hook configuration for zoxide.\n#\n\n"
        if hook == "none":
            body += not_configured + "\n\n"
        else:
            body += f"{fn}__zoxide_hook() {{\n    \\command zoxide add -- \"$(__zoxide_pwd)\"\n}}\n"
            if hook == "prompt":
                body += "PROMPT_COMMAND=\"${PROMPT_COMMAND:+${PROMPT_COMMAND};}__zoxide_hook\"\n\n"
            else:
                body += "__zoxide_oldpwd=\"$(__zoxide_pwd)\"\n\n"
        body += f"{section}\n# When using zoxide with --no-cmd, alias these internal functions as desired.\n#\n\n"
        body += f"{fn}__zoxide_z() {{\n    local result\n    result=\"$(\\command zoxide query --exclude \"$(__zoxide_pwd)\" -- \"$@\")\" && __zoxide_cd \"$result\"\n}}\n\n"
        body += f"{fn}__zoxide_zi() {{\n    local result\n    result=\"$(\\command zoxide query --interactive -- \"$@\")\" && __zoxide_cd \"$result\"\n}}\n\n"
        body += f"{section}\n# Commands for zoxide. Disable these using --no-cmd.\n#\n\n"
        if no_cmd:
            body += not_configured + "\n"
        else:
            body += f"{fn}{cmd}() {{\n    __zoxide_z \"$@\"\n}}\n\n{fn}{zi}() {{\n    __zoxide_zi \"$@\"\n}}\n"
        return body
    if shell == "fish":
        body = f"{section}\n# Utility functions for zoxide.\n#\n\nfunction __zoxide_pwd\n    builtin pwd -L\nend\n\nfunction __zoxide_cd\n    builtin cd $argv\nend\n\n"
        body += f"{section}\n# Hook configuration for zoxide.\n#\n\n"
        body += (not_configured + "\n\n") if hook == "none" else "function __zoxide_hook --on-variable PWD\n    command zoxide add -- (__zoxide_pwd)\nend\n\n"
        body += "function __zoxide_z\n    set -l result (command zoxide query --exclude (__zoxide_pwd) -- $argv); and __zoxide_cd $result\nend\nfunction __zoxide_zi\n    set -l result (command zoxide query --interactive -- $argv); and __zoxide_cd $result\nend\n\n"
        body += not_configured + "\n" if no_cmd else f"alias {cmd}=__zoxide_z\nalias {zi}=__zoxide_zi\n"
        return body
    if shell == "powershell":
        body = "function global:__zoxide_pwd { (Get-Location).ProviderPath }\nfunction global:__zoxide_z { $result = zoxide query -- @args; if ($LASTEXITCODE -eq 0) { Set-Location $result } }\nfunction global:__zoxide_zi { $result = zoxide query -i -- @args; if ($LASTEXITCODE -eq 0) { Set-Location $result } }\n"
        if no_cmd:
            body += "# -- not configured --\n"
        else:
            body += f"Set-Alias -Name {cmd} -Value __zoxide_z -Option AllScope -Scope Global -Force\nSet-Alias -Name {zi} -Value __zoxide_zi -Option AllScope -Scope Global -Force\n"
        return body
    return f"{section}\n# zoxide init for {shell}\n#\nfunction __zoxide_z {{ zoxide query -- \"$@\"; }}\nfunction __zoxide_zi {{ zoxide query -i -- \"$@\"; }}\n"


def cmd_init(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(sub_help("init"))
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write(VERSION)
        return 0
    cmd = "z"
    hook = "pwd"
    no_cmd = False
    shell = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--no-cmd" or arg == "--no-aliases":
            no_cmd = True
        elif arg == "--cmd":
            cmd, i = parse_value(argv, i, "--cmd <CMD>", "executable init [OPTIONS] <SHELL>")
            continue
        elif arg.startswith("--cmd="):
            cmd = arg.split("=", 1)[1]
        elif arg == "--hook":
            hook, i = parse_value(argv, i, "--hook <HOOK>", "executable init [OPTIONS] <SHELL>")
            continue
        elif arg.startswith("--hook="):
            hook = arg.split("=", 1)[1]
        elif arg.startswith("-"):
            return unexpected_arg_error(arg, "executable init <SHELL>")
        elif shell is None:
            shell = arg
        else:
            return unexpected_arg_error(arg, "executable init [OPTIONS] <SHELL>", tip=False)
        i += 1
    if shell is None:
        return usage_error("the following required arguments were not provided:\n  <SHELL>", "executable init <SHELL>")
    allowed = {"bash", "elvish", "fish", "ksh", "nushell", "posix", "powershell", "tcsh", "xonsh", "zsh"}
    if shell not in allowed:
        return invalid_value_error(shell, "<SHELL>", "bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh")
    if hook not in {"none", "prompt", "pwd"}:
        return invalid_value_error(hook, "--hook <HOOK>", "none, prompt, pwd")
    sys.stdout.write(shell_script(shell, cmd=cmd, hook=hook, no_cmd=no_cmd))
    return 0


def autojump_rank(value):
    return 1.0 / (1.0 + math.exp(-value))


def parse_autojump(lines):
    rows = []
    for line in lines:
        if not line.strip():
            continue
        if "\t" not in line:
            raise ZoxideError(f"import error\n\nCaused by:\n    invalid entry: {line}")
        rank_text, path = line.split("\t", 1)
        try:
            rank = float(rank_text)
        except ValueError:
            raise ZoxideError(f"import error\n\nCaused by:\n    0: invalid rank: {rank_text}\n    1: invalid float literal")
        upsert(rows, path, autojump_rank(rank), 0.0)
    return rows


def parse_z(lines):
    rows = []
    for line in lines:
        if not line.strip():
            continue
        parts = line.rsplit("|", 2)
        if len(parts) != 3:
            short = line.split("|")
            if len(short) == 2 and rows:
                raise ZoxideError(f"import error\n\nCaused by:\n    0: invalid epoch: {short[1]}\n    1: invalid digit found in string")
            if len(short) == 2:
                raise ZoxideError(f"import error\n\nCaused by:\n    0: invalid rank: {short[0]}\n    1: invalid float literal")
            raise ZoxideError(f"import error\n\nCaused by:\n    invalid entry: {line}")
        path, rank_text, epoch_text = parts
        try:
            rank = float(rank_text)
        except ValueError:
            raise ZoxideError(f"import error\n\nCaused by:\n    0: invalid rank: {rank_text}\n    1: invalid float literal")
        try:
            epoch = int(epoch_text)
        except ValueError:
            raise ZoxideError(f"import error\n\nCaused by:\n    0: invalid epoch: {epoch_text}\n    1: invalid digit found in string")
        upsert(rows, path, rank, float(epoch))
    return rows


def cmd_import(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(sub_help("import"))
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write(VERSION)
        return 0
    command_preamble()
    source = None
    merge = False
    path = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--from":
            if source is not None:
                return usage_error("the argument '--from <FROM>' cannot be used multiple times", "executable import [OPTIONS] --from <FROM> <PATH>")
            source, i = parse_value(argv, i, "--from <FROM>", "executable import [OPTIONS] --from <FROM> <PATH>")
            continue
        if arg.startswith("--from="):
            if source is not None:
                return usage_error("the argument '--from <FROM>' cannot be used multiple times", "executable import [OPTIONS] --from <FROM> <PATH>")
            source = arg.split("=", 1)[1]
        elif arg == "--merge":
            merge = True
        elif arg.startswith("-"):
            return unexpected_arg_error(arg, "executable import [OPTIONS] --from <FROM> <PATH>")
        else:
            path = arg
        i += 1
    missing = []
    if source is None:
        missing.append("--from <FROM>")
    if path is None:
        missing.append("<PATH>")
    if missing:
        return usage_error("the following required arguments were not provided:\n  " + "\n  ".join(missing), "executable import --from <FROM> <PATH>")
    if source not in {"autojump", "z", "fasd"}:
        return invalid_value_error(source, "--from <FROM>", "autojump, z")
    rows = load_db()
    if rows and not merge:
        return zoxide_error("current database is not empty, specify --merge to continue anyway")
    try:
        lines = open(path, "r", encoding="utf-8", errors="surrogateescape").read().splitlines()
    except OSError as exc:
        return zoxide_error(f"could not open database for importing: {path}\n\nCaused by:\n    {exc.strerror} (os error {exc.errno})")
    imported = parse_autojump(lines) if source == "autojump" else parse_z(lines)
    if not merge:
        rows = []
    for row in imported:
        upsert(rows, row["path"], row["rank"], row["last_access"])
    rows = apply_aging(rows)
    save_db(rows)
    return 0


def cmd_edit(argv):
    if "-h" in argv or "--help" in argv:
        sys.stdout.write(sub_help("edit"))
        return 0
    if "-V" in argv or "--version" in argv:
        sys.stdout.write(VERSION)
        return 0
    command_preamble()
    if not argv:
        return zoxide_error("could not find fzf, is it installed?")
    for arg in argv:
        if arg.startswith("-"):
            return unexpected_arg_error(arg, "executable edit", tip=False)
    sub = argv[0]
    rows = load_db()
    if sub == "reload":
        rows = apply_aging(rows)
        save_db(rows)
        output_edit_rows(rows)
        return 0
    if len(argv) < 2:
        return usage_error("the following required arguments were not provided:\n  <PATH>", "executable edit [COMMAND] <PATH>")
    path = argv[1]
    if sub == "increment":
        upsert(rows, path, 1.0, time.time())
    elif sub == "decrement":
        upsert(rows, path, -1.0, time.time())
    elif sub == "delete":
        rows = [row for row in rows if row["path"] != path]
    else:
        return usage_error(f"unrecognized subcommand '{sub}'", "executable edit [COMMAND] [PATH]")
    rows = apply_aging(rows)
    save_db(rows)
    output_edit_rows(rows)
    return 0


def main(argv):
    try:
        if not argv:
            sys.stderr.write(MAIN_HELP)
            return 2
        if argv[0] in ("-h", "--help"):
            sys.stdout.write(MAIN_HELP)
            return 0
        if argv[0] in ("-V", "--version"):
            sys.stdout.write(VERSION)
            return 0
        if argv[0].startswith("-"):
            return unexpected_arg_error(argv[0], "executable <COMMAND>", tip=False)
        command, rest = argv[0], argv[1:]
        if command == "add":
            return cmd_add(rest)
        if command == "query":
            return cmd_query(rest)
        if command == "remove":
            return cmd_remove(rest)
        if command == "init":
            return cmd_init(rest)
        if command == "import":
            return cmd_import(rest)
        if command == "edit":
            return cmd_edit(rest)
        if command.lower() in {"add", "query", "remove", "init", "import", "edit"}:
            eprint(f"error: unrecognized subcommand '{command}'")
            eprint()
            if command != command.upper():
                eprint(f"  tip: a similar subcommand exists: '{command.lower()}'")
                eprint()
            eprint("Usage: executable <COMMAND>")
            eprint()
            eprint("For more information, try '--help'.")
            return 2
        return usage_error(f"unrecognized subcommand '{command}'", "executable <COMMAND>")
    except UsageExit as exc:
        return exc.code
    except ZoxideError as exc:
        return zoxide_error(str(exc))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

