# CMatrix

Matrix-like effect in your terminal

## Overview

CMatrix is based on the screensaver from The Matrix website. It shows text
flying in and out in a terminal like as seen in "The Matrix" movie. It can
scroll lines all at the same rate or asynchronously and at a user-defined
speed.

CMatrix is inspired from 'The Matrix' movie.

> Disclaimer: We are in no way affiliated with the movie "The Matrix", "Warner Bros" nor
any of its affiliates in any way, just fans.

## Usage

Run CMatrix with the following command:
```sh
cmatrix
```

Run with different arguments to get different effects:
```sh
cmatrix [-abBflohnsmVx] [-u update] [-C color]
```

Example:
```sh
cmatrix -ba -u 2 -C red
```

### Command-line Options

- `-a` - Asynchronous scroll
- `-b` - Bold characters on
- `-B` - All bold characters (overrides -b)
- `-f` - Force the linux $TERM type to be on
- `-l` - Linux mode (sets "matrix.fnt" font in console)
- `-o` - Use old-style scrolling
- `-c` - Only print the shadows of letters
- `-L` - Locks cmatrix, unable to quit
- `-h, -?` - Print usage and exit
- `-r` - "Rainbow" mode, rainbow colored characters
- `-k` - Every characters change
- `-n` - No bold characters (overrides -b and -B)
- `-s` - "Screensaver" mode, exits on first keystroke
- `-m` - "Lambda" mode, every character becomes a lambda
- `-x` - X window mode
- `-V` - Print version information and exit
- `-u delay` - Screen update delay 0-9, default 4
- `-C color` - Use this color for matrix (default green). Valid colors are green, red, blue, white, yellow, cyan, magenta and black.
- `-M message` - Add a message in the center of cmatrix
- `-t tty` - Set tty to use

### Interactive Keystrokes

The following keystrokes are available during execution (unavailable in -s mode):

- `a` - Toggle asynchronous scroll
- `b` - Random bold characters
- `B` - All bold characters
- `n` - Turn off bold characters
- `0-9` - Adjust update speed
- `! @ # $ % ^ & )` - Change the color of the matrix:
  - `!` - red
  - `@` - green
  - `#` - yellow
  - `$` - blue
  - `%` - magenta
  - `^` - cyan
  - `&` - white
  - `)` - black
- `q` - Quit the program

### Tips

- To get the program to look most like the movie, use: `cmatrix -lba`
- To get the program to look most like the Win/Mac screensaver, use: `cmatrix -ol`

Note: cmatrix is probably not particularly portable or efficient, but it won't hog
too much CPU time.

## Screenshots

![cmatrix screenshot](./data/img/capture_bold_font.png)

## Screencasts

![cmatrix screencast](./data/img/capture_orig.gif)

## License

This software is provided under the GNU GPL v3. [View License](./COPYING)
