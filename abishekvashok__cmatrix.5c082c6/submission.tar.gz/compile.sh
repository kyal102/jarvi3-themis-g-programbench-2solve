#!/bin/sh
set -eu
cc main.c -O2 -Wall -Wextra -o executable
