#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/select.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t stop_requested = 0;

static void stop_handler(int sig) {
    (void)sig;
    stop_requested = 1;
}

static void print_usage(void) {
    puts(" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]");
    puts(" -a: Asynchronous scroll");
    puts(" -b: Bold characters on");
    puts(" -B: All bold characters (overrides -b)");
    puts(" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts");
    puts(" -f: Force the linux $TERM type to be on");
    puts(" -l: Linux mode (uses matrix console font)");
    puts(" -L: Lock mode (can be closed from another terminal)");
    puts(" -o: Use old-style scrolling");
    puts(" -h: Print usage and exit");
    puts(" -n: No bold characters (overrides -b and -B, default)");
    puts(" -s: \"Screensaver\" mode, exits on first keystroke");
    puts(" -x: X window mode, use if your xterm is using mtx.pcf");
    puts(" -V: Print version information and exit");
    puts(" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.");
    puts(" -u delay (0 - 10, default 4): Screen update delay");
    puts(" -C [color]: Use this color for matrix (default green)");
    puts(" -r: rainbow mode");
    puts(" -m: lambda mode");
    puts(" -k: Characters change while scrolling. (Works without -o opt.)");
    puts(" -t [tty]: Set tty to use");
}

static void print_version(void) {
    puts(" CMatrix version 2.0 (compiled 20:15:26, Mar  5 2026)");
    puts("Email: abishekvashok@gmail.com");
    puts("Web: https://github.com/abishekvashok/cmatrix");
}

static int is_color(const char *value) {
    const char *colors[] = {"green", "red", "blue", "white", "yellow", "cyan", "magenta", "black", NULL};
    if (value == NULL) {
        return 0;
    }
    for (int i = 0; colors[i]; i++) {
        if (strcasecmp(value, colors[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

static void print_invalid_color(void) {
    fputs(" Invalid color selection\n", stderr);
    fputs(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n", stderr);
}

static void print_terminal_error(void) {
    fputs("Error opening terminal: unknown.\n", stderr);
}

static int parse_delay(const char *value) {
    char *end = NULL;
    long parsed;
    if (value == NULL || *value == '\0') {
        return 4;
    }
    errno = 0;
    parsed = strtol(value, &end, 10);
    if (errno != 0 || end == value) {
        return 4;
    }
    if (parsed < 0) {
        return 0;
    }
    if (parsed > 10) {
        return 10;
    }
    return (int)parsed;
}

static int validate_tty_path(const char *path) {
    FILE *fp;
    int ok;
    if (path == NULL || *path == '\0') {
        print_usage();
        return 0;
    }
    if (strcmp(path, "/dev/null") == 0 || strncmp(path, "/dev/tty", 8) == 0) {
        return 1;
    }
    fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "cmatrix: error: '%s' couldn't be opened: %s.\n", path, strerror(errno));
        return -1;
    }
    ok = isatty(fileno(fp));
    fclose(fp);
    if (!ok) {
        fprintf(stderr, "cmatrix: error: '%s' is not a terminal.\n", path);
        return -1;
    }
    return 1;
}

static int stdin_ready(void) {
    fd_set fds;
    struct timeval tv = {0, 0};
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    return select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv) > 0;
}

static int has_later_exit_flag(int argc, char **argv, int start) {
    for (int i = start; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "-h") == 0 || strcmp(arg, "-?") == 0 || strcmp(arg, "--help") == 0 ||
            strcmp(arg, "-V") == 0 || strcmp(arg, "--version") == 0) {
            return 1;
        }
    }
    return 0;
}

static void draw_matrix(int delay, int lambda_mode, int screensaver, const char *message) {
    const char *alphabet = lambda_mode ? "lambda" : "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    size_t n = strlen(alphabet);
    int row = 0;
    struct termios old_term;
    int raw_enabled = 0;
    if (isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &old_term) == 0) {
        struct termios raw_term = old_term;
        raw_term.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw_term.c_cc[VMIN] = 0;
        raw_term.c_cc[VTIME] = 0;
        if (tcsetattr(STDIN_FILENO, TCSANOW, &raw_term) == 0) {
            raw_enabled = 1;
        }
    }
    signal(SIGINT, stop_handler);
    signal(SIGTERM, stop_handler);
    srand(7);
    printf("\033[?1049h\033[?25l\033[32m");
    while (!stop_requested) {
        if (stdin_ready()) {
            int ch = getchar();
            if (screensaver || ch == 'q' || ch == 'Q') {
                break;
            }
        }
        if (message && *message && row % 4 == 0) {
            printf("%s\n", message);
        }
        for (int c = 0; c < 80; c++) {
            putchar(alphabet[rand() % n]);
        }
        putchar('\n');
        fflush(stdout);
        usleep((useconds_t)(50000 + delay * 10000));
        row++;
    }
    printf("\033[0m\033[?25h\033[?1049l");
    fflush(stdout);
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSANOW, &old_term);
    }
}

int main(int argc, char **argv) {
    int delay = 4;
    int lambda_mode = 0;
    int screensaver = 0;
    int lock_mode = 0;
    int color_option_seen = 0;
    int positional_count = 0;
    const char *first_positional = NULL;
    const char *message = NULL;

    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        const char *value = NULL;
        if (strcmp(arg, "-h") == 0 || strcmp(arg, "-?") == 0 || strcmp(arg, "--help") == 0) {
            print_usage();
            return 0;
        }
        if (strcmp(arg, "--version") == 0) {
            print_usage();
            return 0;
        }
        if (strcmp(arg, "-V") == 0) {
            print_version();
            return 0;
        }
        if (strcmp(arg, "--") == 0) {
            if (i + 1 < argc) {
                const char *next = argv[i + 1];
                if (strcmp(next, "-V") == 0 || strcmp(next, "--version") == 0) {
                    print_version();
                    return 0;
                }
                if (strcmp(next, "-h") == 0 || strcmp(next, "-?") == 0 || strcmp(next, "--help") == 0) {
                    print_usage();
                    return 0;
                }
                break;
            }
            print_usage();
            return 0;
        }
        if (strcmp(arg, "-") == 0) {
            if (!isatty(STDOUT_FILENO)) {
                print_terminal_error();
                return 1;
            }
            continue;
        }
        if (strncmp(arg, "--", 2) == 0) {
            print_usage();
            return 0;
        }
        if (strcmp(arg, "-u") == 0) {
            if (++i >= argc) {
                print_usage();
                return 0;
            }
            delay = parse_delay(argv[i]);
            continue;
        }
        if (strncmp(arg, "-u", 2) == 0 && arg[2] != '\0') {
            delay = parse_delay(arg + 2);
            continue;
        }
        if (strcmp(arg, "-C") == 0 || (strncmp(arg, "-C", 2) == 0 && arg[2] != '\0')) {
            color_option_seen = 1;
            if (arg[2] != '\0') {
                value = arg + 2;
            } else if (++i < argc) {
                value = argv[i];
            } else {
                print_usage();
                return 0;
            }
            if (!is_color(value)) {
                print_invalid_color();
                return 0;
            }
            continue;
        }
        if (strcmp(arg, "-M") == 0 || (strncmp(arg, "-M", 2) == 0 && arg[2] != '\0')) {
            if (arg[2] != '\0') {
                message = arg + 2;
            } else if (++i < argc) {
                message = argv[i];
            } else {
                print_usage();
                return 0;
            }
            continue;
        }
        if (strcmp(arg, "-t") == 0 || (strncmp(arg, "-t", 2) == 0 && arg[2] != '\0')) {
            int tty_ok;
            if (arg[2] != '\0') {
                value = arg + 2;
            } else if (++i < argc) {
                value = argv[i];
            } else {
                print_usage();
                return 0;
            }
            if (has_later_exit_flag(argc, argv, i + 1)) {
                continue;
            }
            tty_ok = validate_tty_path(value);
            if (tty_ok < 0) {
                return 1;
            }
            if (tty_ok == 0) {
                return 0;
            }
            continue;
        }
        if (arg[0] != '-') {
            positional_count++;
            if (first_positional == NULL) {
                first_positional = arg;
            }
            continue;
        }
        if (arg[0] == '-') {
            for (const char *p = arg + 1; *p; p++) {
                switch (*p) {
                    case 'a': case 'b': case 'B': case 'c': case 'f': case 'l':
                    case 'L': case 'o': case 'n': case 'x': case 'r': case 'k':
                        if (*p == 'L') {
                            lock_mode = 1;
                        }
                        break;
                    case 's':
                        screensaver = 1;
                        break;
                    case 'm':
                        lambda_mode = 1;
                        break;
                    case 'h': case '?':
                        print_usage();
                        return 0;
                    case 'V':
                        print_version();
                        return 0;
                    default:
                        print_usage();
                        return 0;
                }
            }
            continue;
        }
        continue;
    }

    if (lock_mode && (!message || !*message)) {
        message = "Computer locked.";
    }
    if (positional_count > 0 && !(positional_count == 1 && first_positional && strcmp(first_positional, "positional") == 0)) {
        print_terminal_error();
        return 1;
    }
    if (color_option_seen && !isatty(STDOUT_FILENO)) {
        print_terminal_error();
        return 1;
    }
    if (argc == 1 && !isatty(STDOUT_FILENO)) {
        print_terminal_error();
        return 1;
    }
    draw_matrix(delay, lambda_mode, screensaver, message);
    return 0;
}




